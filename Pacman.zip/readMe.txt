PacMan - Ex1
Yarden Agami 207471186
Dor Bibas 315557850 

Extras :
	- Full color supporting with switch mode ON\OFF.
	- Custom-Made teleportation with unconventional entrances and exits (not just vertical and horizontal).
	- Hope you enjoy the UI : )  
Notes : 
	we decided to win at 300 points even if we have more points on board.
	we decided not to stop and recalibrate the ghosts when they "eat" the pacman. For more "smoth" game expiriance.
	
