#include "Game.h"

int main() {
	Game game;
	game.Menu();
	return 0;
}