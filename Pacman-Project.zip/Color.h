#pragma once
//
//enum class Color {
//	BLACK,
//	BLUE,
//	GREEN,
//	CYAN,
//	RED,
//	MAGENTA,
//	BROWN,
//	LIGHTGREY,
//	DARKGREY,
//	LIGHTBLUE,
//	LIGHTGREEN,
//	LIGHTCYAN,
//	LIGHTRED,
//	LIGHTMAGENTA,
//	YELLOW,
//	WHITE
//};
